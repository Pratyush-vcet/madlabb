# Flutter Netflix UI Redesign

[YouTube Speed Code](https://youtu.be/sgfMdhV4HQI)

[Design Credit](https://dribbble.com/shots/5026483-Netflix-Mobile-App-Redesign/)